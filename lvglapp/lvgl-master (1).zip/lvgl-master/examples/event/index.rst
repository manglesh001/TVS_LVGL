
Button click event
------------------

.. lv_example:: event/lv_example_event_click
  :language: c

Click streaks
-------------

.. lv_example:: event/lv_example_event_streak
  :language: c

Handle multiple events
----------------------
.. lv_example:: event/lv_example_event_button
  :language: c


Event bubbling
--------------
.. lv_example:: event/lv_example_event_bubble
  :language: c

Draw event
----------
.. lv_example:: event/lv_example_event_draw
  :language: c


