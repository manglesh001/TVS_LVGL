.. _adding_lvgl_to_your_project:

===========================
Adding LVGL to Your Project
===========================


.. toctree::
    :maxdepth: 2

    getting_lvgl
    building_lvgl
    configuration
    connecting_lvgl
    timer_handler
    threading
    other_platforms

