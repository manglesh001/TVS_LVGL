======================================
Espressif Pixel Processing Accelerator
======================================

API
***

:ref:`lv_draw_ppa_h`
