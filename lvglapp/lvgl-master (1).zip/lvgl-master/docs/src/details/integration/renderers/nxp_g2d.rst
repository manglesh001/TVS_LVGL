===========
NXP G2D GPU
===========

API
***

:ref:`lv_draw_g2d_h`
