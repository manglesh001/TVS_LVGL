===============
STM32 DMA2D GPU
===============

API
***

:ref:`lv_draw_dma2d_h`

