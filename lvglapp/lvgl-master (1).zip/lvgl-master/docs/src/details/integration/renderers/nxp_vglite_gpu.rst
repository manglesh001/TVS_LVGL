==============
NXP VGLite GPU
==============

API
***

:ref:`lv_draw_vglite_h`
