.. _observer:

========
Observer
========

.. toctree::
    :maxdepth: 2

    observer
    observer_examples
