.. _widgets:

===========
All Widgets
===========

.. toctree::
    :class:    toctree-1-deep
    :maxdepth: 1

    base_widget

|hr_left_250|

.. toctree::
    :class:    toctree-1-deep
    :maxdepth: 1

    3dtexture
    animimg
    arc
    arclabel
    bar
    button
    buttonmatrix
    calendar
    canvas
    chart
    checkbox
    dropdown
    image
    imagebutton
    keyboard
    label
    led
    line
    list
    lottie
    menu
    msgbox
    roller
    scale
    slider
    spangroup
    spinbox
    spinner
    switch
    table
    tabview
    textarea
    tileview
    win
    new_widget

.. |hr_left_250|  raw:: html

    <hr />
